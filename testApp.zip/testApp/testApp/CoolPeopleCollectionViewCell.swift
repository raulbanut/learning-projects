//
//  CoolPeopleCollectionViewCell.swift
//  testApp
//
//  Created by Banut Raul on 21.07.2023.
//

import UIKit

class CoolPeopleCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
}
